#!/usr/bin/env python

import rospy
import serial

from mobile_robot.msg import gps_data


def talker():
	talker_topic = rospy.Publisher('gps_data', gps_data, queue_size = 20)
	rospy.init_node('gps_data', anonymous = True)
	rate = rospy.Rate(10)
	msg = gps_data()
	ser = serial.Serial("/dev/ttyUSB1", baudrate = 9600)

	while not rospy.is_shutdown():
		mystr = str(ser.readline())
		mylist = mystr.split(",")
		GGA = "$GPGGA"

		if mylist[0]== GGA:
			#print(mylist[0],"latitude:",mylist[2],"longitude:",mylist[4],"altitude:",mylist[9])
			msg.latitude = mylist[2]
			msg.longitude = mylist[4]
			msg.altitude = mylist[9]

			talker_topic.publish(msg.latitude,msg.longitude,msg.altitude)

		rate.sleep()

if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass